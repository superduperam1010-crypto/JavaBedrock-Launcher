package com.example.launcher.mods

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.security.MessageDigest

data class ModInfo(
    val id: String,
    val title: String,
    val description: String,
    val iconUrl: String?,
    val downloads: Int
)

data class ModFile(
    val versionName: String,
    val fileName: String,
    val url: String,
    val sha1: String
)

/**
 * Mod manager berbasis Modrinth API v2.
 * Dependensi: OkHttp (sudah ada di PojavLauncher). JSON memakai org.json bawaan Android.
 * Wajib: User-Agent yang jelas sesuai aturan Modrinth.
 */
class ModrinthModManager(
    private val client: OkHttpClient = OkHttpClient(),
    private val userAgent: String = "NamaAnda/MyLauncher/1.0 (email@anda.com)"
) {
    private val base = "https://api.modrinth.com/v2"

    private fun get(url: String): String {
        val req = Request.Builder().url(url).header("User-Agent", userAgent).build()
        client.newCall(req).execute().use { res ->
            if (!res.isSuccessful) error("HTTP ${res.code}")
            return res.body!!.string()
        }
    }

    /** Cari mod sesuai versi Minecraft dan loader ("fabric", "forge", "quilt", "neoforge"). */
    suspend fun search(
        query: String,
        gameVersion: String,
        loader: String,
        limit: Int = 20
    ): List<ModInfo> = withContext(Dispatchers.IO) {
        val facets = JSONArray()
            .put(JSONArray().put("project_type:mod"))
            .put(JSONArray().put("versions:$gameVersion"))
            .put(JSONArray().put("categories:$loader"))
        val url = "$base/search?query=${URLEncoder.encode(query, "UTF-8")}" +
            "&facets=${URLEncoder.encode(facets.toString(), "UTF-8")}&limit=$limit"
        val hits = JSONObject(get(url)).getJSONArray("hits")
        List(hits.length()) { i ->
            val h = hits.getJSONObject(i)
            ModInfo(
                id = h.getString("project_id"),
                title = h.getString("title"),
                description = h.getString("description"),
                iconUrl = h.optString("icon_url").ifEmpty { null },
                downloads = h.optInt("downloads")
            )
        }
    }

    /** Ambil versi terbaru mod yang cocok dengan versi game + loader. */
    suspend fun latestFile(
        projectId: String,
        gameVersion: String,
        loader: String
    ): ModFile? = withContext(Dispatchers.IO) {
        val url = "$base/project/$projectId/version" +
            "?loaders=${URLEncoder.encode("[\"$loader\"]", "UTF-8")}" +
            "&game_versions=${URLEncoder.encode("[\"$gameVersion\"]", "UTF-8")}"
        val versions = JSONArray(get(url))
        if (versions.length() == 0) return@withContext null
        val v = versions.getJSONObject(0) // sudah urut terbaru
        val files = v.getJSONArray("files")
        var chosen = files.getJSONObject(0)
        for (i in 0 until files.length()) {
            if (files.getJSONObject(i).optBoolean("primary")) {
                chosen = files.getJSONObject(i); break
            }
        }
        ModFile(
            versionName = v.getString("name"),
            fileName = chosen.getString("filename"),
            url = chosen.getString("url"),
            sha1 = chosen.getJSONObject("hashes").getString("sha1")
        )
    }

    /** Unduh ke folder mods instance dan verifikasi SHA-1. */
    suspend fun install(
        file: ModFile,
        modsDir: File,
        onProgress: (Float) -> Unit = {}
    ): File = withContext(Dispatchers.IO) {
        modsDir.mkdirs()
        val out = File(modsDir, file.fileName)
        val req = Request.Builder().url(file.url).header("User-Agent", userAgent).build()
        client.newCall(req).execute().use { res ->
            if (!res.isSuccessful) error("HTTP ${res.code}")
            val body = res.body!!
            val total = body.contentLength().toFloat()
            var done = 0L
            body.byteStream().use { input ->
                out.outputStream().use { output ->
                    val buf = ByteArray(8192)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        output.write(buf, 0, n)
                        done += n
                        if (total > 0) onProgress(done / total)
                    }
                }
            }
        }
        val sha1 = MessageDigest.getInstance("SHA-1").digest(out.readBytes())
            .joinToString("") { "%02x".format(it) }
        if (!sha1.equals(file.sha1, ignoreCase = true)) {
            out.delete()
            error("Checksum tidak cocok, file dihapus")
        }
        out
    }

    /** Daftar mod terpasang. File .disabled = nonaktif. */
    fun listInstalled(modsDir: File): List<File> =
        modsDir.listFiles { f -> f.name.endsWith(".jar") || f.name.endsWith(".jar.disabled") }
            ?.sortedBy { it.name } ?: emptyList()

    fun setEnabled(mod: File, enabled: Boolean): File {
        val target = if (enabled) File(mod.path.removeSuffix(".disabled"))
        else if (mod.name.endsWith(".disabled")) mod else File(mod.path + ".disabled")
        if (target != mod) mod.renameTo(target)
        return target
    }

    fun remove(mod: File) = mod.delete()
}

/* Contoh pemakaian (di ViewModel/Coroutine):
 *
 * val mgr = ModrinthModManager()
 * val results = mgr.search("sodium", "1.20.1", "fabric")
 * val file = mgr.latestFile(results[0].id, "1.20.1", "fabric")
 * if (file != null) mgr.install(file, File(gameDir, "mods")) { p -> /* update progress */ }
 */
