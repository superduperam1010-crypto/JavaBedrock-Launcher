package com.javabedrock.launcher

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var importsText: TextView
    private val imported = mutableListOf<String>()
    private val PICK_PACK = 2001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 13, 24)
        window.navigationBarColor = Color.rgb(8, 13, 24)

        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(8, 13, 24)) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 32, 24, 24)
        }
        scroll.addView(root)

        val title = TextView(this).apply {
            text = "JAVA BEDROCK\nLAUNCHER"
            textSize = 28f
            setTextColor(Color.rgb(66, 217, 255))
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        root.addView(title, matchWrap())
        addText(root, "JAVA  •  BEDROCK  •  MODS", 13f, Color.LTGRAY, 18)
        addText(root, "Versi prototipe 0.1.0", 14f, Color.WHITE, 4)
        addText(root, "Dashboard awal untuk pengelolaan file Minecraft. Mesin Minecraft Java belum terintegrasi pada prototipe ini.", 14f, Color.LTGRAY, 18)

        button(root, "☕  MINECRAFT JAVA") {
            Toast.makeText(this, "Mesin Java belum terintegrasi. Ini baru prototipe UI.", Toast.LENGTH_LONG).show()
        }
        button(root, "🧱  Impor Addon Bedrock (.mcaddon / .mcpack)") { pickPack() }
        button(root, "📦  Impor Mod Java (.jar)") { pickJar() }
        button(root, "🔎  Modrinth") {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://modrinth.com"))
            startActivity(i)
        }
        addText(root, "FILE YANG DIPILIH", 16f, Color.rgb(66, 217, 255), 22)
        importsText = TextView(this).apply {
            text = "Belum ada file dipilih.\nFile yang dipilih hanya dicatat di layar prototipe; belum dipasang ke game."
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(14, 14, 14, 14)
            setBackgroundColor(Color.rgb(20, 29, 46))
        }
        root.addView(importsText, matchWrap())
        addText(root, "Catatan: dukungan pemasangan otomatis memerlukan integrasi direktori game dan berbeda antara Java dan Bedrock. Windows/Linux direncanakan sebagai aplikasi desktop terpisah.", 12f, Color.LTGRAY, 24)
        setContentView(scroll)
    }

    private fun pickPack() = openPicker(arrayOf("application/octet-stream", "*/*"), "Pilih .mcaddon atau .mcpack")
    private fun pickJar() = openPicker(arrayOf("application/java-archive", "application/octet-stream", "*/*"), "Pilih .jar")
    private fun openPicker(types: Array<String>, title: String) {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, types)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivityForResult(Intent.createChooser(intent, title), PICK_PACK)
    }
    @Deprecated("Legacy picker callback for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_PACK && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            val name = uri.lastPathSegment ?: uri.toString()
            imported.add(name)
            importsText.text = imported.joinToString("\n") + "\n\nBelum dipasang ke game; ini hanya daftar file yang dipilih."
            Toast.makeText(this, "File dipilih: $name", Toast.LENGTH_SHORT).show()
        }
    }
    private fun addText(parent: LinearLayout, value: String, size: Float, color: Int, top: Int) {
        val t = TextView(this).apply { text = value; textSize = size; setTextColor(color); setPadding(0, top, 0, 0) }
        parent.addView(t, matchWrap())
    }
    private fun button(parent: LinearLayout, label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label; isAllCaps = false; textSize = 15f
            setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(23, 73, 105)); setOnClickListener { action() }
        }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = 10
        parent.addView(b, lp)
    }
    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
}
