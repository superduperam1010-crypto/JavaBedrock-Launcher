# JavaBedrock Launcher — Android Starter

An Android Studio/Gradle starter project for a Java + Bedrock Minecraft launcher concept.

## Current status
This builds a **prototype UI APK**, not a complete Minecraft launcher. The buttons for launching Java and installing mods/addons are placeholders. File picking currently lists the selected filename only; it does not install it into a game directory. No Minecraft game files are bundled.

## Build on a phone with GitHub Actions
1. Upload the contents of this folder to a new GitHub repository (the `.github/workflows/build-apk.yml` file must be included).
2. Open the repository's **Actions** tab.
3. Select **Build Android APK** and tap **Run workflow**, or push a commit to `main`.
4. Open the completed workflow run, scroll to **Artifacts**, and download `JavaBedrock-Launcher-debug-apk`.
5. Extract the downloaded artifact ZIP to get `app-debug.apk`.

## Next engineering milestones
- Integrate a maintained Android Java launcher/runtime project after reviewing its license and build instructions.
- Implement real mod profile storage, version/loader installation, and Modrinth API integration.
- Implement Bedrock pack import into supported game storage locations, subject to Android version and storage permissions.
- Build separate desktop applications for Windows and Linux; the Android APK cannot run on those systems.
